import React from 'react';
 class forgotpassword extends Component {
     constructor(props) {
         super(props);
         this.state = {  }
     }
     render() { 
         return ( 
             <div>
                 <h1>forgot password</h1>
             </div>
          );
     }
 }
  
 export default forgotpassword;