import React from 'react';
import ReactDOM from 'react-dom';
import GridTableData from "./GridTableData.jsx";

ReactDOM.render(<GridTableData />, document.getElementById('app'));
