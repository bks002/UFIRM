//import Catalog from './catalog/reducer';
import Commonreducer from './department/reducer';

const Admin = {};

export default {
  //Catalog,
  Commonreducer,
  Admin,

};
