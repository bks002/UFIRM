import React from 'react';

class Fileuploaderjs  {
    Initializeuploader(){
        
       
    }
}
export default Fileuploaderjs;