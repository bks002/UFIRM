﻿// all common function 

class ServiceCommon {

    

}

export default ServiceCommon;