/*
Created By:Sanjay Vishwakarma
Date:Dec 28 2018
Decription: collection of web api urls 
*/

class APIUrlProvider {
    constructor() {


        this.MainUrl = "https://admin-api.urest.in/api/" 
        //this.MainUrl = "https://localhost:62058/api/"
        
        this.complaintUrl  = "https://urest.in/complaint/"
        // this.complaintUrl  = "http://localhost:62929/"

    }
}
export default APIUrlProvider;