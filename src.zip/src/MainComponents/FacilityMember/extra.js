{/* <ImageUploader
                                                                    singleImage={true}
                                                                    //withIcon={true}
                                                                    withIcon={false}
                                                                    withPreview={true}
                                                                    label=""
                                                                    // label="Max file size: 5mb, accepted: jpg, png, svg"
                                                                    buttonText="Upload Images"
                                                                    onChange={this.onImageChange.bind(this)}
                                                                    imgExtension={[".jpg", ".png", ".svg"]}
                                                                    maxFileSize={5242880}
                                                                    fileSizeError=" file size is too big"
                                                                /> */}