/*
Created By:Ravindra Vishwakarma
Date:May 8 2020
Decription: collection of web api urls 
*/

class APIUrlProvider {
    constructor() {

        this.MainUrl = "http://localhost:59287/";

    }
}
export default APIUrlProvider;