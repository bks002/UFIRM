import React from 'react'
class PropertyManager extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <h1> this is react component</h1>
        );
    }
}
export default PropertyManager;
