﻿import React from 'react';
import ReactDOM from 'react-dom';
import PriceUpload from "./PriceUpload.jsx"

ReactDOM.render(<PriceUpload /> , document.getElementById('priceupload'));