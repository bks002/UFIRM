﻿import React from 'react';
import ReactDOM from 'react-dom';
import PriceBrowse from "./PriceBrowse.jsx"


ReactDOM.render(<PriceBrowse /> , document.getElementById('pricebrowse'));