﻿import React from 'react';
import ReactDOM from 'react-dom';
import ConnectionProfile from "./ConnectionProfile.jsx"

ReactDOM.render(<ConnectionProfile /> , document.getElementById('ConnectionProfile'));