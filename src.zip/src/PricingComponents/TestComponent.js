import React from 'react';
import ReactDOM from 'react-dom';
import TestComponent from './TestComponent.jsx';

ReactDOM.render(<TestComponent /> , document.getElementById('app'));