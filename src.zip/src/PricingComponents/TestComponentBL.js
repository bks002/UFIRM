class TestComponentBL  {

    
   
}
 
export default TestComponentBL ;