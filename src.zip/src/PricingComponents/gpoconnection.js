﻿import React from 'react';
import ReactDOM from 'react-dom';
import PricingComponent from "./PricingConnection.jsx"
import FileUplaod from "../ReactComponents/FileUploader/FileUploader.jsx"

ReactDOM.render(<PricingComponent /> , document.getElementById('app'));
