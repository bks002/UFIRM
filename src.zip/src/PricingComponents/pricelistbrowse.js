﻿import React from 'react';
import ReactDOM from 'react-dom';
import PriceListBrowse from "./PriceListBrowse.jsx";


ReactDOM.render(<PriceListBrowse /> , document.getElementById('pricelistbrowse'));