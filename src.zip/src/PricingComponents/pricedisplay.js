﻿import React from 'react';
import ReactDOM from 'react-dom';
import PriceDisplay from "./PriceDisplay.jsx"

ReactDOM.render(<PriceDisplay /> , document.getElementById('pricedisplay'));

