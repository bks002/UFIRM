import React from 'react';

export default  class login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
               <h1> Login Page </h1>
            </div>
         );
    }
}
 
