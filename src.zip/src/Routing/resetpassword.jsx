import React from 'react';
export default  class resetpassword extends React.Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
                <h1> Reset password.......</h1>
            </div>
         );
    }
}
 
