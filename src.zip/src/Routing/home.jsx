import React from 'react';
export default class home extends React.Component {
    constructor(props) {
        super(props);
        this.state = { 

         }
    }
    render() { 
        return (
            <h1>home</h1>
          );
    }
}
 
